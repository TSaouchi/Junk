package com.example.appa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppAMain {
    public static void main(String[] args) {
        SpringApplication.run(AppAMain.class, args);
    }
}