package com.example.appa;

import com.example.shared.ModuleAService;
import org.springframework.stereotype.Service;

@Service
public class ModuleAServiceImpl implements ModuleAService {
    @Override
    public String processA(String input) {
        return "Processed by A: " + input;
    }
}