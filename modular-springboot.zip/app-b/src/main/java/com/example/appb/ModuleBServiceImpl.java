package com.example.appb;

import org.springframework.stereotype.Service;

@Service
public class ModuleBServiceImpl {
    public String processB(String input) {
        return "Processed by B: " + input;
    }
}