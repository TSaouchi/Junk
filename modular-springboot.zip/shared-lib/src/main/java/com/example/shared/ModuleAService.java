package com.example.shared;

public interface ModuleAService {
    String processA(String input);
}