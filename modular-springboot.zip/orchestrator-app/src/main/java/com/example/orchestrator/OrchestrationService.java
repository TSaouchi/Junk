package com.example.orchestrator;

import com.example.shared.ModuleAService;
import com.example.appb.ModuleBServiceImpl;
import com.example.appc.ModuleCServiceImpl;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Service;

@Service
public class OrchestrationService implements CommandLineRunner {

    private final ModuleAService moduleAService;
    private final ModuleBServiceImpl moduleBService;
    private final ModuleCServiceImpl moduleCService;

    public OrchestrationService(ModuleAService moduleAService,
                                ModuleBServiceImpl moduleBService,
                                ModuleCServiceImpl moduleCService) {
        this.moduleAService = moduleAService;
        this.moduleBService = moduleBService;
        this.moduleCService = moduleCService;
    }

    @Override
    public void run(String... args) {
        String a = moduleAService.processA("start");
        String b = moduleBService.processB(a);
        String c = moduleCService.processC(b);
        System.out.println("Orchestration result: " + c);
    }
}