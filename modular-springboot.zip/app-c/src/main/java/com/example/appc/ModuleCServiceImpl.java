package com.example.appc;

import org.springframework.stereotype.Service;

@Service
public class ModuleCServiceImpl {
    public String processC(String input) {
        return "Processed by C: " + input;
    }
}