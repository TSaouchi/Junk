package com.example.aggregate.service;

import com.example.aggregate.domain.BaseData;
import com.example.aggregate.domain.AssetData;
import com.example.aggregate.domain.Security;
import com.example.aggregate.mapper.ReferenceMapper;
import com.example.aggregate.model.AggregateModel;
import org.springframework.stereotype.Service;

@Service
public class AggregateService {

    private final BaseDataClassificationEngine baseClassificationEngine;
    private final AssetDataClassificationEngine assetClassificationEngine;
    private final ReferenceMapper referenceMapper;
    

    public AggregateService(BaseDataClassificationEngine baseClassificationEngine,
                            AssetDataClassificationEngine assetClassificationEngine,
                            ReferenceMapper referenceMapper) {
        this.baseClassificationEngine = baseClassificationEngine;
        this.assetClassificationEngine = assetClassificationEngine;
        this.referenceMapper = referenceMapper;
    }

    public AggregateModel build(Security externalUser, String infoType) {
        AggregateModel model = new AggregateModel();

        BaseData user = baseClassificationEngine.classify(externalUser);
        model.setBase(user);
        
        AssetData asset = assetClassificationEngine.classify(externalUser);
        model.setAsset(asset);

        // Generic reference mapping
        model.setReference(referenceMapper.toReferences(externalUser));

        return model;
    }
}
