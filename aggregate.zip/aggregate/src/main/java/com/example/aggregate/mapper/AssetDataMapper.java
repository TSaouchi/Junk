package com.example.aggregate.mapper;

import com.example.aggregate.domain.OptionData;
import com.example.aggregate.domain.EquityData;
import com.example.aggregate.domain.Security;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface AssetDataMapper {

    EquityData toEquityData(Security externalUser);

    OptionData toOptionData(Security externalUser);
}
