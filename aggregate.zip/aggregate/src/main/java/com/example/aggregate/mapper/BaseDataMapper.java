package com.example.aggregate.mapper;

import com.example.aggregate.domain.Security;
import com.example.aggregate.domain.PriceBaseData;
import com.example.aggregate.domain.ProductBaseData;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

@Mapper(componentModel = "spring")
public interface BaseDataMapper {

    PriceBaseData toPriceBaseData(Security externalUser);
    
    
    @Mapping(source = "TOTOO", target = "popo",  qualifiedByName = "convertToPopo")
    @Mapping(source = "LALAA", target = "papa")
    ProductBaseData toProductBaseData(Security externalUser);

    // Custom method used by MapStruct for TOTOO -> popo mapping
    @Named("convertToPopo")
    default String convertToPopo(Integer totoo) {
        if (totoo == null) return null;
        if (totoo == 15) return "Equity";
        return totoo.toString(); // fallback if not 15
    }
}
