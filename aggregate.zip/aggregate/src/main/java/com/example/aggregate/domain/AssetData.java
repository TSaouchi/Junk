package com.example.aggregate.domain;

import lombok.Data;

@Data
public class AssetData {}