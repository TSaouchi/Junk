package com.example.aggregate.domain;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class PriceBaseData extends BaseData {
    private String name;
    private String email;
    private String department;
    private String salary;
}