package com.example.aggregate.domain;

import lombok.Data;

@Data
public class Security {
    private String type;
    private String name;
    private String username;
    private String email;
    private String salary;
    private String phoneNumber;
    private String department;
    private Integer TOTOO;
    private String LALAA;
    private String ric;
    private String adp;
    private String mure;
    private String assetType;
}
