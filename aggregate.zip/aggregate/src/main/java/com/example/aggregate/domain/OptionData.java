package com.example.aggregate.domain;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class OptionData extends AssetData {
    private String medicalRecord;
    private String insuranceNumber;
    private String salary;
}
