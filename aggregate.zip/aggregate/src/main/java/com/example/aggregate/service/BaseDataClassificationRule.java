package com.example.aggregate.service;

import com.example.aggregate.domain.BaseData;
import com.example.aggregate.domain.Security;

public interface BaseDataClassificationRule {
    boolean matches(Security externalUser);
    BaseData map(Security externalUser);
}
