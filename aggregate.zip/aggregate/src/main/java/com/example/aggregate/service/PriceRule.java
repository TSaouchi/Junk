package com.example.aggregate.service;

import com.example.aggregate.domain.BaseData;
import com.example.aggregate.domain.Security;
import com.example.aggregate.mapper.BaseDataMapper;
import org.springframework.stereotype.Component;

@Component
public class PriceRule implements BaseDataClassificationRule {

    private final BaseDataMapper baseDataMapper;

    public PriceRule(BaseDataMapper baseDataMapper) {
        this.baseDataMapper = baseDataMapper;
    }

    @Override
    public boolean matches(Security externalUser) {
        try {
            return externalUser.getType() == "Price";
        } catch (NumberFormatException e) {
            return false;
        }
    }

    @Override
    public BaseData map(Security externalUser) {
        return baseDataMapper.toPriceBaseData(externalUser);
    }
}
