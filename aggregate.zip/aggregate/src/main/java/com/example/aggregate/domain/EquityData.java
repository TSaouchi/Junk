package com.example.aggregate.domain;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class EquityData extends AssetData {
    private String location;
    private String phoneNumber;
}