package com.example.aggregate.service;

import com.example.aggregate.domain.AssetData;
import com.example.aggregate.domain.Security;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AssetDataClassificationEngine {

    private final List<AssetDataClassificationRule> rules;

    public AssetDataClassificationEngine(List<AssetDataClassificationRule> rules) {
        this.rules = rules;
    }

    public AssetData classify(Security externalUser) {
        return rules.stream()
                .filter(rule -> rule.matches(externalUser))
                .findFirst()
                .map(rule -> rule.map(externalUser))
                .orElseThrow(() -> new IllegalArgumentException("No matching user rule found"));
    }
}
