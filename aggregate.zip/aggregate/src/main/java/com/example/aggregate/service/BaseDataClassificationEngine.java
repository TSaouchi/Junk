package com.example.aggregate.service;

import com.example.aggregate.domain.BaseData;
import com.example.aggregate.domain.Security;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BaseDataClassificationEngine {

    private final List<BaseDataClassificationRule> rules;

    public BaseDataClassificationEngine(List<BaseDataClassificationRule> rules) {
        this.rules = rules;
    }

    public BaseData classify(Security externalUser) {
        return rules.stream()
                .filter(rule -> rule.matches(externalUser))
                .findFirst()
                .map(rule -> rule.map(externalUser))
                .orElseThrow(() -> new IllegalArgumentException("No matching user rule found"));
    }
}
