package com.example.aggregate.domain;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class ProductBaseData extends BaseData {
    private String name;
    private String username;
    private String phoneNumber;
    private String popo;
    private String papa;
}