package com.example.aggregate.model;

import com.example.aggregate.domain.BaseData;
import com.example.aggregate.domain.AssetData;
import com.example.aggregate.domain.ReferenceData;
import lombok.Data;

import java.util.List;

@Data
public class AggregateModel {
    private BaseData base;
    private AssetData asset;
    private List<ReferenceData> reference;
}
