package com.example.aggregate.mapper;

import com.example.aggregate.domain.CrossRefData;
import com.example.aggregate.domain.ReferenceData;
import org.mapstruct.Mapper;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Mapper(componentModel = "spring")
public abstract class ReferenceMapper {

    // Hardcoded mappings instead of injecting from CrossRefProperties
    protected Map<String, Map<String, String>> mappings;

    public ReferenceMapper() {
        // initialize mappings
        mappings = new HashMap<>();

        Map<String, String> userMap = new HashMap<>();
        userMap.put("ric", "Ricora");
        userMap.put("adp", "Adopera");
        userMap.put("mure", "Murelia");
        userMap.put("department", "DeptCode");

        mappings.put("productxrefdata", userMap);
    }

    public List<ReferenceData> toReferences(Object source) {
        List<ReferenceData> refs = new ArrayList<>();
        
        Map<String, String> mappingForClass = mappings.get("productxrefdata");
        if (mappingForClass == null) return refs;
        mappingForClass.forEach((fieldName, targetName) -> {
            String value = extractValue(source, fieldName);
            if (value != null) {
                refs.add(new CrossRefData(targetName, value));
            }
        });

        return refs;
    }

    private String extractValue(Object source, String fieldName) {
        try {
            Field field = source.getClass().getDeclaredField(fieldName);
            field.setAccessible(true);
            Object value = field.get(source);
            return value != null ? value.toString() : null;
        } catch (NoSuchFieldException | IllegalAccessException e) {
            return null;
        }
    }
}
