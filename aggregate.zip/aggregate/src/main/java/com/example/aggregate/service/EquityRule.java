package com.example.aggregate.service;

import com.example.aggregate.domain.AssetData;
import com.example.aggregate.domain.Security;
import com.example.aggregate.mapper.AssetDataMapper;
import org.springframework.stereotype.Component;

@Component
public class EquityRule implements AssetDataClassificationRule {

    private final AssetDataMapper assetDataMapper;

    public EquityRule(AssetDataMapper assetDataMapper) {
        this.assetDataMapper = assetDataMapper;
    }

    @Override
    public boolean matches(Security externalUser) {
        try {
            return externalUser.getAssetType().equals("Equity");
        } catch (NumberFormatException e) {
            return false;
        }
    }

    @Override
    public AssetData map(Security externalUser) {
        return assetDataMapper.toEquityData(externalUser);
    }
}
