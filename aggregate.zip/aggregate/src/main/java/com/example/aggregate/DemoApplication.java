package com.example.aggregate;

import com.example.aggregate.domain.Security;
import com.example.aggregate.model.AggregateModel;
import com.example.aggregate.service.AggregateService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoApplication implements CommandLineRunner {

    private final AggregateService aggregateService;

    public DemoApplication(AggregateService aggregateService) {
        this.aggregateService = aggregateService;
    }

    public static void main(String[] args) {
        SpringApplication.run(DemoApplication.class, args);
    }

    @Override
    public void run(String... args) {
        Security user = new Security();
        user.setName("Alice");
        user.setType("Product");
        user.setAssetType("Option");
        user.setDepartment("Finance");
        user.setSalary("7000");
        user.setRic("RIC-12345");
        user.setAdp("ADP-999");
        user.setMure("MURE-777");
        user.setTOTOO(100);
        user.setLALAA("INS-555");

        System.out.println(user);

        AggregateModel aggregate = aggregateService.build(user, "HEALTH");

        System.out.println("---------------------");
        System.out.println(aggregate);
        System.out.println("---------------------");
        // System.out.println("=== User Aggregate ===");
        // System.out.println("User type: " + aggregate.getUser().getClass().getSimpleName());
        // System.out.println("Info type: " + aggregate.getInfo().getClass().getSimpleName());
        // aggregate.getReference().forEach(ref ->
        //         System.out.println(((com.example.aggregate.domain.CrossRef) ref).getNatRrefName() + " -> " +
        //                 ((com.example.aggregate.domain.CrossRef) ref).getNatRefValue())
        // );
    }
}
