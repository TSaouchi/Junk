package com.example.aggregate.service;

import com.example.aggregate.domain.AssetData;
import com.example.aggregate.domain.Security;

public interface AssetDataClassificationRule {
    boolean matches(Security externalUser);
    AssetData map(Security externalUser);
}